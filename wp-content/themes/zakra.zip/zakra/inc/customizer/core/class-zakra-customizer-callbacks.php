<?php
/**
 * Zakra customizer class for theme customize callbacks.
 *
 * Class Zakra_Customizer_FrameWork_FrameWork_Callbacks
 *
 * @package    ThemeGrill
 * @subpackage Zakra
 * @since      Zakra 3.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Zakra customizer class for theme customize callbacks.
 *
 * Class Zakra_Customizer_FrameWork_Callbacks
 */
class Zakra_Customizer_FrameWork_Callbacks {

}
